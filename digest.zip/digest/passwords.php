<?php
/* Copyright (c) 2015 djalex88
 * MIT license; see digest.php */

/* Enter a password for each user you want to grant access to the admin panel.
 * For security reasons, you should move this file to some directory not accessible from the Internet
 * but don't forget to specify its absolute path before activating the plugin! */

$passwords = array(
	// 'username' => 'password'
);
